engine.exe  
    Official Windows runtime.

AI_ENGINE_MANUAL.md  
    Complete public game-authoring API and behavior reference.

On first run, `engine.exe` creates/materializes the editable `project/` starter project if it does not already exist.

For game development, modify `project/`.  
Do not modify the engine.

The separate Source distribution contains engine source, tests, build tooling, and the complete example library.