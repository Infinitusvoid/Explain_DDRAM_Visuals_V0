# Stateless Pointcloud World V11 GameReady Patch 5
# BLACK-BOX AI GAME SDK MANUAL

**Purpose:** this file is the complete black-box authoring contract for an AI or human who receives the compiled executable but **does not receive the C++ engine source**.

A project author should be able to create, run, hot-reload, debug and render a full game/world using only:

```text
engine.exe
STATELESS_POINTCLOUD_WORLD_V11_BLACKBOX_AI_SDK_MANUAL.md
project/                     # optional initially; the EXE can bootstrap one
```

The engine source is **not required** for normal game creation. Game content is authored in AngelScript, GLSL, JSON/data, textures and audio files under `project/`.

This manual documents the complete current engine-facing AngelScript registration surface, all string-valued engine options found in the current runtime, important defaults/clamps, automatic GLSL uniforms, callbacks, resource rules, collision/audio/input/video semantics and known deliberate limitations. When this manual and an old example disagree, prefer this manual for **V11 GameReady Patch 5**.

---

## 1. Fast start: building a game with only the EXE

### Minimal folder

```text
MyGame/
  engine.exe
  STATELESS_POINTCLOUD_WORLD_V11_BLACKBOX_AI_SDK_MANUAL.md
```

On first launch, if no external `project/scene.as` can be found, the EXE materializes its embedded editable starter project beside itself and immediately uses it.

### Project search order

The runtime looks for `project/scene.as` in this order:

1. beside the executable;
2. if the executable itself is inside a folder literally named `build`, the parent of that `build` folder;
3. the current working directory;
4. if none exists, it creates the embedded starter beside the executable.

If an existing project is found, the bootstrapper does **not** inject tutorial files into it.

### Smallest hand-written project

```text
MyGame/
  engine.exe
  project/
    scene.as
    shaders/
      points.vert
      points.frag
```

`project/scene.as`:

```cpp
void build_scene(Scene@ scene)
{
    ShaderLayer@ layer = scene.create_layer(
        "main",
        "project/shaders/points.vert",
        "project/shaders/points.frag"
    );

    GameObject@ object = scene.create_object("cloud", layer);
    object.set_point_count(1000000);
    object.set_batch_size(250000);
}
```

`project/shaders/points.vert`:

```glsl
#version 460 core

uniform mat4 u_view_projection;
uniform float u_time;

void main()
{
    uint id = uint(gl_VertexID);
    float f = float(id);
    vec3 p = vec3(
        sin(f * 0.013 + u_time),
        sin(f * 0.017) * 0.5,
        cos(f * 0.011 + u_time)
    ) * 8.0;
    gl_Position = u_view_projection * vec4(p, 1.0);
    gl_PointSize = 2.0;
}
```

`project/shaders/points.frag`:

```glsl
#version 460 core
layout(location=0) out vec4 out_color;
void main() { out_color = vec4(0.4, 0.8, 1.0, 1.0); }
```

That is enough to create a million-point procedural world without a mesh file.

---

## 2. Engine mental model

The intended architecture is deliberately small:

```text
Scene
  ├─ ShaderLayer                         render/compute material + shared layer properties
  │    └─ GameObject                     semantic transform + population + object properties
  │         └─ renderer draw batches     implementation detail; logical IDs stay stable
  ├─ Group                               transform hierarchy shared by rendering/collision
  ├─ Collider / CharacterController      semantic collision, not rigid-body physics
  ├─ Texture2D                           GPU-owned shared textures/images
  ├─ PostProcessPass                     ordered fullscreen passes
  ├─ camera path / float tracks
  ├─ serializable Scene properties
  └─ immediate overlay
```

Use a **small number of CPU-side semantic objects** and let GLSL/compute generate large populations. Do not create one CPU object per point.

The engine is native Win32/OpenGL 4.6. GLSL `#version 460 core` is the recommended shader version for this build.

---

## 3. Project layout and paths

A useful project layout is:

```text
project/
  scene.as
  scripts/
  shaders/
  glsl/
  post/
  textures/
  audio/
  data/
  state/
```

Paths passed to engine APIs are ordinary filesystem paths. The safest portable convention is always to use paths rooted at `project/`, for example:

```cpp
layer.set_texture("u_palette", "project/textures/palette.png");
uint sound = audio_play("project/audio/door.wav");
Json@ data = json_load("project/data/world.json");
```

Output-writing APIs create parent directories where their implementation explicitly supports it (JSON save, scene-state save, buffer save, video output).

---

## 4. Script lifecycle and callback order

### Required root callback

Every project root script must define:

```cpp
void build_scene(Scene@ scene)
```

This constructs the candidate Scene during startup/reload.

### Optional root update

```cpp
void update_scene(Scene@ scene, float time, float dt)
```

Use this for live game state, input, UI, audio actions, camera control and per-frame orchestration.

### Optional ShaderLayer attached script

Attach using:

```cpp
layer.set_script("project/scripts/layer_logic.as");
```

The module may define:

```cpp
void on_shader_update(Scene@ scene, ShaderLayer@ layer, float time, float dt)
```

### Optional GameObject attached script

Attach using:

```cpp
object.set_script("project/scripts/object_logic.as");
```

The module may define:

```cpp
void on_start(Scene@ scene, GameObject@ object)
void on_update(Scene@ scene, GameObject@ object, float time, float dt)
```

`on_start` runs once for the current accepted script generation before that object's first `on_update`.

### Per-frame scheduling rule

The effective order is:

1. root `update_scene`;
2. pending object destruction is flushed;
3. attached scripts may hot-reload;
4. the attached-callback schedule is frozen for this frame;
5. ShaderLayer `on_shader_update` callbacks;
6. GameObject `on_start`/`on_update` callbacks;
7. pending object destruction is flushed again;
8. compute/render/post/overlay proceed in the host frame;
9. collision trigger results become the script-visible trigger event set for the next script frame.

Structural changes or attached-script changes made by attached callbacks are intentionally observed cleanly on the next frame rather than recursively mutating the schedule currently being executed.

---

## 5. Hot reload and last-known-good behavior

The runtime is designed for live editing.

### AngelScript includes

Quoted includes are supported:

```cpp
#include "lib/player.as"
```

They resolve relative to the including script. The transitive dependency graph is watched. Editing a nested included file dirties the owning scene/attached module.

### GLSL includes

Quoted GLSL includes are supported in vertex, fragment, compute and post roots:

```glsl
#version 460 core
#include "../glsl/noise.glsl"
```

Rules:

- includes resolve relative to the including shader;
- includes are transitive and hot-reload watched;
- included modules should **not** declare their own `#version`; keep `#version` in the root shader;
- missing files/include cycles/compile failures reject the candidate;
- live rendering keeps the previous valid shader when the edited candidate fails;
- F9 final rendering requires the current files on disk to compile and does not silently use stale live shader programs.

### Scene reload transaction

A structural reload builds a candidate world/VM/resources first. Failed candidates do not casually replace the accepted live world. This is why `build_scene()` should be treated as construction, not as a place for irreversible live side effects.

Audio, input-claim and GPU-readback side effects are constrained/suppressed during candidate construction where needed for transaction safety.

---

## 6. Native controls and input ownership

Default live controls when scripts do not claim them:

```text
W A S D         fly camera
Space / Ctrl    camera up / down
Shift           fast movement
mouse           camera look
mouse wheel     camera movement speed
Escape          release cursor capture (reserved system escape)
F1              help
F2              live stats
F3              scene summary
F4              camera-key helper
F5              force shader / attached-script reload
F6              Scene reload, keep camera
F7              fresh reload; reset camera after successful commit
F8              snapshot
F9              deterministic video render
F10             camera-path preview toggle
F11             fullscreen
```

### Key-name normalization

Key strings are case-insensitive after removing non-alphanumeric characters. Therefore `"Left Ctrl"`, `"left_ctrl"`, and `"leftctrl"` normalize to the same spelling **if** that normalized spelling is a recognized alias.

Recognized keys:

```text
A..Z
0..9
space
escape, esc
enter, return
tab
backspace
insert
delete, del
right, left, down, up
pageup, pagedown
home, end
capslock, scrolllock, numlock
printscreen
pause
leftshift, rightshift
leftcontrol, leftctrl
rightcontrol, rightctrl
leftalt, rightalt
leftsuper, rightsuper
menu
apostrophe
comma
minus
period
slash
semicolon
equal
leftbracket
backslash
rightbracket
graveaccent, backtick
f1..f12
```

`claim_key("escape")` is intentionally ignored. Escape remains the host escape/cursor-release control.

### Mouse button indices

```text
0 = left
1 = right
2 = middle
3 = button 4
4 = button 5
5 = button 6
6 = button 7
7 = button 8
```

Invalid mouse-button indices return false/do nothing.

### Claim pattern for a game controller

```cpp
void build_scene(Scene@ scene)
{
    claim_key("w"); claim_key("a"); claim_key("s"); claim_key("d");
    claim_key("space"); claim_key("leftctrl"); claim_key("leftshift");
    claim_mouse_motion(true);
    claim_mouse_scroll(true);
}
```

Claims prevent the native fly camera from consuming those controls; the query APIs still let the script read them.

`clear_input_claims()` releases all script claims.

Input edge queries mean:

- `key_down` / `mouse_down`: currently held;
- `key_pressed` / `mouse_pressed`: transitioned down this frame;
- `key_released` / `mouse_released`: transitioned up this frame.

`mouse_x/y` are host mouse coordinates. `mouse_delta_x/y` are per-frame deltas. `mouse_scroll()` returns the frame's vertical wheel delta.

---

## 7. Camera API

Default fly camera state:

```text
position          (0, 7, 28)
yaw               -90 degrees
pitch             -10 degrees
FOV                60 degrees
move speed          7
fast multiplier     4
mouse sensitivity   0.11
captured             true
```

Script camera getters/setters act on the active host/render camera:

```cpp
camera_x(); camera_y(); camera_z();
camera_yaw(); camera_pitch(); camera_fov();
camera_set_position(x,y,z);
camera_set_angles(yaw,pitch);
camera_set_fov(fov);
```

Clamps:

```text
camera_set_angles pitch: [-89, +89] degrees
camera_set_fov:          [5, 170] degrees
```

Yaw is not forcibly wrapped; periodic yaw values are valid.

World up is +Y.

---

## 8. Math and deterministic random helpers

Value types:

```cpp
Vec2(float x, float y)
Vec3(float x, float y, float z)
Vec4(float x, float y, float z, float w)
```

All have zero-valued default constructors and public components. They support vector add/subtract, unary negation, scalar multiply/divide. Helpers include `dot`, `cross(Vec3)`, `length`, `normalize`, and `lerp`.

Deterministic hash/random helpers:

```cpp
uint hash_u32(uint seed)
float random_01(uint seed)
float random_range(uint seed, float minimum, float maximum)
```

Use stable IDs such as `gl_VertexID`, object IDs, explicit seeds or frame indices when deterministic procedural output matters.

---

## 9. Scene, Groups and transforms

### Groups

`Group` is the shared hierarchy anchor for rendering and collision. Local transform defaults:

```text
position = (0,0,0)
rotation = (0,0,0) degrees
scale    = (1,1,1)
enabled  = true
parent   = none
```

Local matrix order is:

```text
T * Rz * Ry * Rx * S
```

A disabled group disables descendants for rendering. Parent cycles are rejected.

Use:

```cpp
scene.get_world_position(group)
scene.get_world_position(object)
scene.transform_point(group, local_point)
scene.inverse_transform_point(group, world_point)
```

rather than reproducing hierarchy math. `inverse_transform_point` raises a script exception when the world transform is singular/invalid.

### GameObject transform

A GameObject has a local transform applied after its Group hierarchy:

```text
world_model = group_world * object_local
```

Rotation setters use degrees.

### Scene properties vs shader properties

`Scene.set_float/int/uint/vec3` are Scene state properties used by the Scene state serializer. They are **not** the same thing as ShaderLayer/GameObject uniform properties.

The public Scene API currently has getters only for float/int/uint. There is no public `get_vec3` method in Patch 5, even though vec3 Scene properties can be stored/serialized. Do not invent one.

---

## 10. ShaderLayer rendering state

A new layer defaults to:

```text
enabled      true
blend mode   opaque
primitive    points
depth test   true
depth write  true
point size   1.0
line width   1.0
compute      disabled
```

Depth comparison is **less-or-equal**.

### Blend mode accepted strings

`set_blend_mode` is case-insensitive and returns false for unknown strings.

```text
opaque:              "opaque", "off", "none"
alpha:               "alpha", "standard_alpha"
additive:            "additive", "add"
premultiplied alpha: "premultiplied", "premultiplied_alpha", "premul"
multiply:            "multiply", "mul"
```

Blend equations/factors:

```text
Opaque:
  blending disabled

Alpha:
  color = src * srcAlpha + dst * (1-srcAlpha)
  alpha = src * 1        + dst * (1-srcAlpha)

Additive:
  color = src * srcAlpha + dst * 1
  alpha = src * 1        + dst * 1

Premultiplied:
  color = src * 1 + dst * (1-srcAlpha)
  alpha = src * 1 + dst * (1-srcAlpha)

Multiply:
  color = src * dstColor + dst * 0
  alpha = src * 1        + dst * 0
```

`set_additive(true)` is compatibility shorthand for additive. `set_additive(false)` selects **opaque**; it does not restore a previously selected blend mode.

### Primitive accepted strings

```text
points:         "points", "point"
lines:          "lines", "line"
line strip:     "line_strip", "linestrip", "strip"
triangles:      "triangles", "triangle"
triangle strip: "triangle_strip", "trianglestrip", "ribbon"
```

`set_primitive` returns false for an unknown string.

### Point and line size

`set_point_size()` feeds automatic `u_point_size`; the vertex shader may use that value to set `gl_PointSize`. Program point size is enabled.

`set_line_width()` stores the requested width. For line/line-strip draws, the renderer asks the backend for at least `1.0`; actual wide-line support remains GPU/driver dependent.

---

## 11. GameObject populations, LOD and batching

New object defaults:

```text
point_count          1,000,000
batch_size           1,000,000
enabled              true
LOD                   disabled
LOD near              20
LOD far               200
LOD far fraction      0.05
visibility distance   0  (unlimited)
transform             identity
```

`set_point_count(0)` becomes 1. `set_batch_size(0)` becomes 1.

### Stable logical ID contract

`batch_size` is a submission/performance knob, **not** a logical-address-space change. Draw calls use a `first_vertex` offset so `gl_VertexID` continues to represent the logical vertex ID.

Example:

```glsl
uint id = uint(gl_VertexID);
uint tree = id / 5000u;
uint point_in_tree = id % 5000u;
```

### LOD

```cpp
object.set_lod(near_distance, far_distance, far_fraction);
```

Clamps:

```text
near_distance >= 0
far_distance  >= near_distance + 0.001
far_fraction  in [0,1]
```

The rendered population fraction is 1.0 at/before near distance, linearly interpolates to `far_fraction`, then remains at `far_fraction` at/after far distance. The engine submits at least one logical element before primitive-alignment rules.

`clear_lod()` disables distance LOD.

`set_visibility_distance(v)`: `v <= 0` means unlimited; positive values cull the whole object when its world origin is farther than `v` from the camera.

### Primitive-safe batching

- points: arbitrary chunks;
- lines: only complete pairs;
- triangles: only complete triples;
- line strip: next batch repeats the previous endpoint;
- triangle strip/ribbon: next batch repeats the final edge, and non-final batch parity is kept compatible with the monolithic strip.

LOD counts are also aligned down for independent line/triangle group sizes. Line strips need at least 2 rendered vertices; triangle strips need at least 3.

---

## 12. GLSL automatic uniforms

Declare only the uniforms you need. The runtime reflects shader resources/uniforms and sets known values when they exist.

### Graphics stages

```glsl
uniform mat4  u_view;
uniform mat4  u_projection;
uniform mat4  u_view_projection;
uniform vec3  u_camera_position;
uniform float u_time;
uniform float u_delta_time;
uniform vec2  u_resolution;
uniform uint  u_frame_index;
uniform uint  u_layer_id;
uniform float u_point_size;

uniform uint  u_object_id;
uniform uint  u_object_point_count;
uniform uint  u_object_render_point_count;
uniform float u_object_lod_fraction;
uniform mat4  u_model;
uniform mat4  u_inverse_model;
uniform vec3  u_object_world_position;

// legacy local-transform uniforms kept for compatibility:
uniform vec3  u_object_position;
uniform vec3  u_object_rotation;
uniform vec3  u_object_scale;
```

`u_object_rotation` is in degrees and is the object's **local** raw rotation, not a decomposed world rotation. Prefer `u_model` for new work.

### Compute stage

```glsl
uniform float u_time;
uniform float u_delta_time;
uniform uint  u_frame_index;
uniform uint  u_layer_id;
uniform vec3  u_camera_position;
```

plus ShaderLayer custom properties.

### Post stage

```glsl
uniform sampler2D u_input;       // automatic previous pass when declared and not overridden
uniform vec2      u_resolution;  // this pass's actual target size
uniform float     u_time;
uniform uint      u_pass_index;
```

plus PostProcessPass custom properties.

### Custom uniform types

ShaderLayer and GameObject can upload:

```text
float, int, uint, vec2, vec3, vec4
```

PostProcessPass can upload:

```text
float, vec2, vec3, vec4
```

Scene property setters are a separate state system as noted earlier.

### Graphics custom-property precedence

For each layer/object draw:

1. engine automatic uniforms;
2. ShaderLayer custom properties;
3. per-object automatic uniforms;
4. GameObject custom properties.

GameObject custom properties therefore override same-named layer custom properties for that draw. The renderer also resets object-only custom uniform values when moving to an object that does not define them, preventing accidental OpenGL uniform-state leakage between objects.

---

## 13. File-backed textures

```cpp
layer.set_texture("u_albedo", "project/textures/a.png");
layer.set_texture("u_data",   "project/textures/data.png", false);
```

Arguments:

```text
uniform name
file path
srgb = true by default
```

The image is decoded and uploaded as 8-bit RGBA. With `srgb=true` it uses an sRGB RGBA8 texture; with false it uses linear/unorm RGBA8.

The bundled decoder has its ordinary JPEG, PNG, BMP, PSD, TGA, GIF, HDR, PIC and PNM/PPM/PGM loaders enabled. The `set_texture` path nevertheless converts through the engine's 8-bit RGBA upload path.

Sampler behavior for these file textures is linear min/mag filtering, repeat addressing, no mipmap chain.

Binding is by GLSL sampler uniform name. Explicit `layout(binding=N)` is recommended for clarity, but reflected ordinary sampler uniforms are supported.

File changes participate in resource hot reload.

Remove with:

```cpp
layer.clear_texture("u_albedo");
```

---

## 14. Scene-owned Texture2D and storage images

Create GPU-owned shared textures:

```cpp
Texture2D@ field = scene.create_texture_2d("field", 1024, 1024, "rgba16f");
```

Width/height are at least 1.

Accepted format strings:

```text
rgba8
r32f,     r32_float
rgba16f,  rgba16_float
rgba32f,  rgba32_float
r32ui,    r32_uint
rgba32ui, rgba32_uint
```

`Texture2D.get_format()` returns the canonical spelling (`rgba8`, `r32f`, etc.).

Sampling binding:

```cpp
layer.bind_texture("u_field", field);
```

Storage-image binding:

```cpp
layer.bind_image("u_field_image", field, "write");
```

Accepted image access strings:

```text
read:       "read", "read_only", "readonly"
write:      "write", "write_only", "writeonly"
read/write: "read_write", "readwrite", "rw"
```

`bind_image` returns false for invalid access or invalid binding conditions.

GLSL image declarations must use a format qualifier compatible with the texture format and readonly/writeonly qualifiers must not contradict the binding access.

Scene-owned integer textures use nearest sampling; non-integer shared textures use linear sampling. Shared textures use clamp-to-edge and no mipmaps.

Remove sampled/image bindings with:

```cpp
layer.clear_shared_texture("u_field");
layer.clear_image("u_field_image");
```

---

## 15. SSBO buffers: vec4 and uvec4

Create buffers on a layer:

```cpp
layer.create_vec4_buffer("ControlPoints", 1000000, true);
layer.create_uvec4_buffer("Flags",       1000000, true);
```

`count` is forced to at least 1.

One block name belongs to one type. You cannot reuse `"ControlPoints"` as both vec4 and uvec4. `get_io_error()` explains type/name/file failures.

`dynamic=false` is the default. It selects the less CPU-oriented GPU storage usage; `dynamic=true` is intended for buffers updated often from the CPU. Both can still be changed through the public update API.

Update CPU-mirror values:

```cpp
layer.set_buffer_vec4("ControlPoints", i, x,y,z,w);
layer.set_buffer_uvec4("Flags", i, a,b,c,d);
```

Writing beyond the current size grows the CPU mirror and causes the required transactional GPU-layer rebuild rather than silently overrunning storage.

GLSL examples:

```glsl
layout(std430, binding=3) buffer ControlPoints {
    vec4 points[];
};

layout(std430, binding=4) buffer Flags {
    uvec4 flags[];
};
```

Resource reflection matches the block name.

### SWV4 binary format

```text
byte 0..3    ASCII "SWV4"
uint32 LE    version = 1
uint32 LE    vec4 count
uint32 LE    reserved = 0
payload      count * 4 float32 values (16 bytes per vec4)
```

### SWU4 binary format

```text
byte 0..3    ASCII "SWU4"
uint32 LE    version = 1
uint32 LE    uvec4 count
uint32 LE    reserved = 0
payload      count * 4 uint32 values (16 bytes per uvec4)
```

Load/save:

```cpp
layer.load_vec4_buffer("ControlPoints", "project/data/points.swv4", true);
layer.save_vec4_buffer("ControlPoints", "project/data/points.swv4");
layer.load_uvec4_buffer("Flags", "project/data/flags.swu4", true);
layer.save_uvec4_buffer("Flags", "project/data/flags.swu4");
```

Files are strictly validated for magic/version/payload size/trailing data. Buffer save creates parent directories.

### GPU -> CPU readback

Compute writes change GPU memory, not automatically the CPU mirror. Before saving/reading compute-mutated content on CPU, explicitly call:

```cpp
gpu_readback_vec4_buffer(layer, "ControlPoints");
gpu_readback_uvec4_buffer(layer, "Flags");
```

Readback is synchronous and may stall. It is deliberately unavailable during candidate `build_scene()` construction and deterministic F9 rendering; failures are reported through `layer.get_io_error()`.

---

## 16. Compute pre-pass

A ShaderLayer can have one optional compute pre-pass:

```cpp
layer.set_compute_shader("project/shaders/sim.comp", groups_x, groups_y, groups_z);
```

Each group count is forced to at least 1. Clear with `clear_compute_shader()`.

The compute pass runs once for each enabled layer before its graphics use in the frame pipeline. It sees the layer's reflected SSBOs/shared textures/images and the compute automatic uniforms.

After dispatch, the engine inserts a barrier equivalent to:

```text
previous: storage write | image write
next:     storage read | texture read | vertex read
```

Therefore same-frame workflows such as:

```text
compute writes Texture2D image
        -> automatic barrier
vertex/fragment samples same Texture2D
```

are supported without a script-side sync call.

---

## 17. HDR and post-processing

HDR is opt-in:

```cpp
scene.set_hdr(true);
```

Default: `false`.

- HDR false: world/post color path is sRGB RGBA8; final pass copies.
- HDR true: world/post color path is RGBA16F; built-in final output applies `c / (1 + c)` tone mapping to nonnegative RGB and writes sRGB output.

Add passes in desired order:

```cpp
PostProcessPass@ bloom = scene.add_post_process(
    "bloom",
    "project/post/bloom.frag"
);
bloom.set_scale(0.5);
```

New pass defaults:

```text
enabled = true
scale   = 1.0
```

`set_scale` clamps to `[0.01, 1.0]`.

### Named pass inputs

The virtual source name `"scene"` is always available. A pass may reference only `"scene"` or an **earlier enabled pass name**:

```cpp
blur.set_input("u_source", "scene");
composite.set_input("u_blur", "blur");
```

Enabled pass names must be non-empty and unique. Referencing a later, disabled or unknown source rejects validation.

If a post shader declares `u_input` and you did not explicitly override that uniform with `set_input`, the runtime automatically binds the immediately previous stage output.

Post passes render fullscreen triangles with depth disabled and ordinary post output replacement (no layer blend mode).

Overlay UI is drawn **after** the world post/final tone-map chain, so HUD text/rectangles do not bloom with the world.

---

## 18. Collision system

This is semantic collision/query/controller support, **not** a general rigid-body simulator.

World up is +Y.

Colliders are anchored to `Group` transforms. Immediate queries synchronize current Group transforms, so changing a Group earlier in a script update is visible to a later ray/overlap/sweep in that same update.

### Collider defaults

```text
enabled = true
trigger = false
layer   = 1
mask    = 0xFFFFFFFF
user_id = 0
local position = (0,0,0)
local rotation = (0,0,0) degrees
```

### Shapes

```cpp
Collider@ box = scene.create_box_collider("wall", group, Vec3(1,2,0.2));
Collider@ sph = scene.create_sphere_collider("orb", group, 0.5);
Collider@ cap = scene.create_capsule_collider("body", group, 0.35, 0.9);
Collider@ tri = scene.create_triangle_collider("ramp", group, a,b,c);
```

Box half extents use absolute component values. Sphere/capsule radius is at least `0.001`. Capsule half-height is at least 0.

`Collider.set_position/rotation` is local relative to its anchor Group; rotation is degrees.

Layer/mask are 32-bit bitfields. Query `layer_mask` filters collider layers. Trigger/native collider pair filtering also respects collider layer/mask semantics.

### Queries

```cpp
RayHit raycast(origin, direction, max_distance, layer_mask=0xFFFFFFFF)
OverlapHit overlap_sphere(center, radius, layer_mask=0xFFFFFFFF)
OverlapHit overlap_capsule(center, radius, half_height, layer_mask=0xFFFFFFFF)
SweepHit sweep_capsule(center, delta, radius, half_height, layer_mask=0xFFFFFFFF)
```

Ray direction is normalized internally; a degenerate direction falls back to +Z internally rather than producing undefined normalization.

The public overlap calls return one representative hit: from the engine's bounded internal hit set they choose the contact with greatest penetration depth. They do not return an array of all overlaps.

### CharacterController

Create on an existing Group:

```cpp
CharacterController@ c = scene.create_character_controller("player", player_group);
```

Passing null/no Group returns null.

Defaults:

```text
radius                0.35
half_height           0.9
step_height           0.35
ground_snap_distance  0.15
slope_limit_degrees   45
collision_mask        0xFFFFFFFF
```

Setters:

```text
radius:      positive else 0.01
half_height: positive else 0
step:        max(value,0)
ground snap: max(value,0)
slope limit: stored as supplied; converted to cosine at movement time
```

Movement:

```cpp
MoveResult r = c.move(velocity, dt);
```

The engine performs geometric move-and-slide and writes the resulting world position back to the attached Group (preserving parented-group semantics when possible). **Your script owns gravity, acceleration, jump state and game rules.**

Patch 5 rule: ground snap is not allowed to cancel a deliberate velocity component in positive world-up direction. This is the jump fix.

### Trigger events

```cpp
uint n = scene.get_trigger_event_count();
for(uint i=0; i<n; ++i) {
    TriggerEvent e = scene.get_trigger_event(i);
}
```

Types:

```text
Enter = 0
Stay  = 1
Exit  = 2
```

Fields expose both collider IDs and both `user_id` values. Trigger events generated at the end of a host frame are the visible event set on the next script frame.

---

## 19. Audio

Audio is available in the Win32 interactive build through miniaudio.

```cpp
bool audio_available();
```

Non-spatial:

```cpp
uint h = audio_play("project/audio/music.wav", true);
```

Spatial:

```cpp
uint h = audio_play_spatial("project/audio/hum.wav", true, Vec3(0,2,0));
```

Handle `0` means failure/unavailable. Valid handles are nonzero.

Spatial default attenuation:

```text
model        linear
min distance 1.0
max distance 50.0
rolloff      1.0
```

Setters clamp:

```text
volume       >= 0
pan          [-1,1]
min distance >= 0.001
max distance >= 0.001
rolloff      >= 0
master volume >= 0
```

The live listener follows the active camera, with world up +Y.

Use `audio_set_position` to move a spatial sound. `audio_set_spatial_enabled` can toggle spatialization on a handle. `audio_is_playing` checks live state; one-shot sounds are cleaned up after reaching the end.

F9 deterministic video rendering intentionally does not emit live audio side effects and does not mux game audio into the rendered MP4. Mix/render audio separately if the final video needs sound.

WAV is a safe project format. Other formats depend on the bundled miniaudio decoder configuration; if portability matters, prefer WAV rather than relying on an undocumented codec in a game package.

---

## 20. Immediate overlay UI

```cpp
ui_rect(x, y, width, height, r,g,b,a);
ui_text(text, x, y, size, r,g,b,a);
```

Coordinates use normalized top-left convention:

```text
(0,0) = top-left
(1,1) = bottom-right
```

Commands are immediate/frame-local; issue them each frame you want them visible.

`ui_text` size is clamped to at least `0.001`. Position/size/color are otherwise passed as supplied rather than clamped to 0..1.

Overlay is rendered after post/tone mapping. F9 includes deterministic overlay visuals.

---

## 21. JSON and persistent Scene state

### General JSON

```cpp
Json@ j = json_load("project/data/config.json");
Json@ obj = json_object();
Json@ arr = json_array();
```

Check `is_valid()` and `error()` after load/operations where failure matters.

JSON supports object access, array access, numeric/bool/string conversion with fallbacks, object setters, array pushes, pretty/non-pretty save/dump.

`save(path, pretty=true)` creates parent directories.

### Scene state JSON

Scene state is separate from arbitrary `Json` objects:

```cpp
scene.set_float("health", 80.0);
scene.set_int("chapter", 3);
scene.set_uint("flags", 7);
scene.set_vec3("spawn", 1,2,3);
scene.save_state_json("project/state/save.json");
scene.load_state_json("project/state/save.json");
```

The state file uses:

```json
{
  "format": "StatelessWorldState",
  "version": 1,
  "properties": { ... }
}
```

The serializer understands property types float, int, uint, vec2, vec3 and vec4, but the **current public Scene setter surface** exposes float/int/uint/vec3 and current public getters expose only float/int/uint. Do not assume missing Scene vec getters exist.

Use `scene.get_state_io_error()` after false returns.

---

## 22. Camera paths, float tracks and F9 video

### Camera path

```cpp
scene.clear_camera_path();
scene.add_camera_key(time, x,y,z, yaw,pitch, fov);
```

Key times are clamped to nonnegative and sorted. Camera-path interpolation uses position/FOV interpolation and angle-aware yaw/pitch interpolation. Before the first key, the first key is used; after the last, the last key is used.

The `add_camera_key` default FOV is 60; stored key FOV is constrained to a sensible renderer range (the camera-path implementation uses its own key clamp). F10 previews/stops the scene camera path in live mode.

### Float tracks

```cpp
scene.clear_float_track("door");
scene.add_float_key("door", 0.0, 0.0);
scene.add_float_key("door", 2.0, 1.0);
float v = scene.sample_float_track("door", time, 0.0);
```

Times are clamped to nonnegative and sorted. Sampling linearly interpolates, holds the first/last value outside the key range, and returns the fallback when no track/key exists.

### Video defaults

```text
resolution     3840 x 2160
fps            60
duration       4.0 seconds
output         renders/StatelessPointcloudWorld_Showcase_4K60.mp4
ffmpeg args    -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart
use camera path true
```

Clamps:

```text
width/height: [16, 16384]
fps:          [1, 240]
duration:     [1/240, 3600] seconds
```

F9 requires `ffmpeg` discoverable by the Windows command `where ffmpeg` (normally install FFmpeg and put it on PATH). The engine creates the parent output directory.

Output path must be non-empty and may not contain a quote character.

### F9 deterministic contract

F9:

1. creates a fresh script VM and fresh Scene from files on disk;
2. uses that fresh Scene's video settings;
3. validates current shader/resource files rather than accepting stale live shader programs;
4. uses exact `time = frame / fps` and `dt = 1 / fps`;
5. runs the game update/callback/compute/render/post/overlay pipeline;
6. suppresses live input/audio/GPU-readback side effects that would break determinism;
7. reads RGBA8 frames and pipes them to FFmpeg.

F9 is video-only/silent from the game-audio perspective.

---

## 23. Destruction, copying and IDs

`Scene.create_*` resources receive stable nonzero IDs within a Scene generation. `find_layer/object/group/texture_2d(id)` returns the current object for that ID or null when absent.

`copy_object(source, new_name)` clones a GameObject's declarative object state while assigning a new object ID; always pass the second string argument in AngelScript because that is the registered script signature.

`destroy_object(object)` marks/queues object destruction safely; destruction is flushed at controlled callback boundaries. Do not continue treating a destroyed object as a live gameplay entity.

---

## 24. Error handling rules

Many setters are `void`; validation failures therefore surface during scene/shader synchronization with console diagnostics and a rejected candidate rather than as immediate script return values.

Functions that directly report validity include:

```text
ShaderLayer.set_blend_mode        bool
ShaderLayer.set_primitive         bool
ShaderLayer.bind_image            bool
buffer load/save                  bool + get_io_error()
GPU readback                      bool + get_io_error()
Scene state load/save             bool + get_state_io_error()
Json save/load validity           Json validity/error or bool
Audio handle operations           bool / handle 0
Scene.destroy_object              bool
```

When live shader hot reload fails, the previous valid shader generally remains active. When F9 runs, current files must be valid.

Keep the application console visible during development; AngelScript compiler diagnostics include file/row/column, and shader/include diagnostics preserve source-path context.

---

## 25. Things the engine intentionally does NOT provide

Do not invent these APIs:

- no Unity-style ECS/component database;
- no general mesh asset/PBR material pipeline as the primary model;
- no rigid-body physics solver;
- no navmesh/pathfinding system;
- no prefab/asset database;
- no retained GUI editor API;
- no networking API;
- no automatic game save system beyond the documented JSON/state/buffer facilities;
- no automatic audio capture/mux in F9;
- no public `Scene.get_vec3` in Patch 5;
- no script API for changing fly-camera speed/sensitivity directly (you can claim input and implement your own controller/camera behavior);
- no promise that every GPU supports arbitrary wide OpenGL lines identically.

The intended strength is procedural GPU worlds, point/line/ribbon/triangle generation, hot-reloadable scripting and shaders, semantic collision, data buffers/textures/compute, post effects, audio, UI and deterministic video.

---

## 26. Recommended AI workflow

When an AI receives the EXE and this manual:

1. Read this whole manual before inventing API calls.
2. Inspect/create only `project/` content; do not require engine source.
3. Start with `project/scene.as` and small shader files.
4. Keep shared reusable GLSL in include files.
5. Use AngelScript for game orchestration/state/input and GLSL/compute for large populations.
6. Use Groups as semantic transforms for objects/collision.
7. Build collision geometry deliberately; verify stairs/ramps/openings physically.
8. Claim input when replacing native fly controls.
9. Use JSON/state/SWV4/SWU4 for persistence and data interchange.
10. Treat F9 as a fresh deterministic build-from-disk validation path.
11. If an API is not present in Appendix A, do not assume it exists.
12. If a string option is not listed in this manual, do not invent a spelling; use one of the documented values.

---

## 27. Complete option/default checklist

### ShaderLayer

```text
enabled: true
blend: opaque
primitive: points
depth_test: true
depth_write: true
point_size: 1
line_width: 1
compute: off
```

### GameObject

```text
enabled: true
point_count: 1,000,000
batch_size: 1,000,000
position: 0,0,0
rotation: 0,0,0 degrees
scale: 1,1,1
LOD: off (stored defaults near 20, far 200, far fraction .05)
visibility distance: 0 = unlimited
```

### Group

```text
enabled: true
parent: none
position: 0,0,0
rotation: 0,0,0 degrees
scale: 1,1,1
```

### Collider

```text
enabled: true
trigger: false
layer: 1
mask: 0xFFFFFFFF
user_id: 0
local pos/rot: zero
```

### CharacterController

```text
radius .35
half-height .9
step .35
ground snap .15
slope 45 degrees
mask 0xFFFFFFFF
```

### Scene

```text
HDR false
video 3840x2160 @ 60 fps, 4 sec
video camera path true
```

### PostProcessPass

```text
enabled true
scale 1.0
```

### File texture

```text
sRGB true
linear sampling
repeat addressing
no mipmaps
```

### Shared Texture2D

```text
size min 1x1
integer formats nearest
float/unorm formats linear
clamp-to-edge
no mipmaps
```

### Spatial audio

```text
linear attenuation
min 1
max 50
rolloff 1
```

---

## 28. Practical recipes

### Script-controlled first-person movement skeleton

```cpp
Group@ g_player;
CharacterController@ g_controller;
Vec3 g_velocity;
float g_yaw = -90.0;
float g_pitch = 0.0;

void build_scene(Scene@ scene)
{
    claim_key("w"); claim_key("a"); claim_key("s"); claim_key("d");
    claim_key("space"); claim_key("leftshift");
    claim_mouse_motion(true);

    @g_player = scene.create_group("player");
    g_player.set_position(0, 2, 0);
    @g_controller = scene.create_character_controller("player_controller", g_player);
    g_controller.set_capsule(0.35, 0.9);
}

void update_scene(Scene@ scene, float time, float dt)
{
    g_yaw += mouse_delta_x() * 0.11;
    g_pitch -= mouse_delta_y() * 0.11;
    if(g_pitch > 89) g_pitch = 89;
    if(g_pitch < -89) g_pitch = -89;

    float yr = g_yaw * 0.01745329252;
    Vec3 forward(cos(yr), 0, sin(yr));
    Vec3 right(-forward.z, 0, forward.x);
    Vec3 wish;
    if(key_down("w")) wish = wish + forward;
    if(key_down("s")) wish = wish - forward;
    if(key_down("d")) wish = wish + right;
    if(key_down("a")) wish = wish - right;
    if(length(wish) > 0.001) wish = normalize(wish);

    g_velocity.x = wish.x * 5.0;
    g_velocity.z = wish.z * 5.0;
    g_velocity.y -= 18.0 * dt;

    MoveResult r = g_controller.move(g_velocity, dt);
    g_velocity = r.velocity;
    if(r.grounded && g_velocity.y < 0) g_velocity.y = 0;
    if(r.grounded && key_pressed("space")) g_velocity.y = 7.0;

    Vec3 p = scene.get_world_position(g_player);
    camera_set_position(p.x, p.y + 0.65, p.z);
    camera_set_angles(g_yaw, g_pitch);
}
```

### Compute -> texture -> graphics

```cpp
void build_scene(Scene@ scene)
{
    Texture2D@ field = scene.create_texture_2d("field", 1024, 1024, "rgba16f");
    ShaderLayer@ layer = scene.create_layer("field_layer",
        "project/shaders/field.vert", "project/shaders/field.frag");

    layer.bind_image("u_field_out", field, "write");
    layer.bind_texture("u_field", field);
    layer.set_compute_shader("project/shaders/field.comp", 64, 64, 1);

    GameObject@ obj = scene.create_object("field_points", layer);
    obj.set_point_count(1000000);
}
```

### Multi-pass post

```cpp
void build_scene(Scene@ scene)
{
    scene.set_hdr(true);

    PostProcessPass@ bloom = scene.add_post_process("bloom", "project/post/bloom.frag");
    bloom.set_scale(0.5);

    PostProcessPass@ grade = scene.add_post_process("grade", "project/post/grade.frag");
    grade.set_input("u_bloom", "bloom");
    grade.set_float("u_strength", 0.7);
}
```

### Trigger identification

```cpp
Collider@ trigger = scene.create_box_collider("door_trigger", door_group, Vec3(1,2,1));
trigger.set_trigger(true);
trigger.set_user_id(1001);
```

then in update:

```cpp
for(uint i=0; i<scene.get_trigger_event_count(); ++i)
{
    TriggerEvent e = scene.get_trigger_event(i);
    if(e.type == Enter && e.trigger_user_id == 1001)
        print("Entered door trigger");
}
```

---

## 29. Black-box compatibility promise for AI authors

For ordinary project creation, an AI should never need to inspect C++ source merely to discover:

- what callbacks exist;
- which AngelScript functions/types/methods exist;
- valid input names;
- valid primitive/blend/texture/image-access strings;
- default object/layer/controller/video behavior;
- automatic GLSL uniforms;
- file buffer formats;
- post dependency rules;
- collision semantics;
- audio/UI semantics;
- deterministic F9 behavior.

Those are documented here. If a future engine version adds or changes public behavior, this file should be regenerated/updated in the same commit and its API inventory should be checked against the host registration code.

## Appendix A — Exact engine scripting API inventory

This appendix is generated from the current host registration calls in `ScriptRuntime.cpp`, `ScriptJson.cpp`, and `ScriptTypes.cpp`. It contains **304 registered engine-facing declarations** when constructors, properties, enum values, methods and globals are counted individually. It is intended as the no-guessing checklist.

### Global functions

```cpp
void print(const string &in)
float sin(float)
float cos(float)
float sqrt(float)
uint hash_u32(uint)
float random_01(uint)
float random_range(uint, float, float)
void claim_key(const string &in)
void release_key(const string &in)
void clear_input_claims()
bool key_down(const string &in)
bool key_pressed(const string &in)
bool key_released(const string &in)
void claim_mouse_button(int)
void release_mouse_button(int)
void claim_mouse_motion(bool = true)
void claim_mouse_scroll(bool = true)
bool mouse_down(int)
bool mouse_pressed(int)
bool mouse_released(int)
float mouse_x()
float mouse_y()
float mouse_delta_x()
float mouse_delta_y()
float mouse_scroll()
float camera_x()
float camera_y()
float camera_z()
float camera_yaw()
float camera_pitch()
float camera_fov()
void camera_set_position(float, float, float)
void camera_set_angles(float, float)
void camera_set_fov(float)
bool audio_available()
uint audio_play(const string &in, bool = false)
uint audio_play_spatial(const string &in, bool, const Vec3 &in)
bool audio_stop(uint)
bool audio_set_volume(uint, float)
bool audio_set_pan(uint, float)
bool audio_set_position(uint, const Vec3 &in)
bool audio_set_min_distance(uint, float)
bool audio_set_max_distance(uint, float)
bool audio_set_rolloff(uint, float)
bool audio_set_spatial_enabled(uint, bool)
bool audio_is_playing(uint)
void audio_set_master_volume(float)
void audio_stop_all()
void ui_rect(float, float, float, float, float = 1, float = 1, float = 1, float = 1)
void ui_text(const string &in, float, float, float = 0.04, float = 1, float = 1, float = 1, float = 1)
bool gpu_readback_vec4_buffer(ShaderLayer@, const string &in)
bool gpu_readback_uvec4_buffer(ShaderLayer@, const string &in)
Json@ json_load(const string &in)
Json@ json_object()
Json@ json_array()
float dot(const Vec2 &in, const Vec2 &in)
float dot(const Vec3 &in, const Vec3 &in)
float dot(const Vec4 &in, const Vec4 &in)
Vec3 cross(const Vec3 &in, const Vec3 &in)
float length(const Vec2 &in)
float length(const Vec3 &in)
float length(const Vec4 &in)
Vec2 normalize(const Vec2 &in)
Vec3 normalize(const Vec3 &in)
Vec4 normalize(const Vec4 &in)
Vec2 lerp(const Vec2 &in, const Vec2 &in, float)
Vec3 lerp(const Vec3 &in, const Vec3 &in, float)
Vec4 lerp(const Vec4 &in, const Vec4 &in, float)
```

### `Scene`

Methods:

```cpp
ShaderLayer@ create_layer(const string &in, const string &in, const string &in)
GameObject@ create_object(const string &in, ShaderLayer@)
GameObject@ copy_object(GameObject@, const string &in)
bool destroy_object(GameObject@)
Group@ create_group(const string &in)
Collider@ create_box_collider(const string &in, Group@, Vec3)
Collider@ create_sphere_collider(const string &in, Group@, float)
Collider@ create_capsule_collider(const string &in, Group@, float, float)
Collider@ create_triangle_collider(const string &in, Group@, Vec3, Vec3, Vec3)
CharacterController@ create_character_controller(const string &in, Group@)
RayHit raycast(Vec3, Vec3, float, uint = 0xFFFFFFFF)
OverlapHit overlap_sphere(Vec3, float, uint = 0xFFFFFFFF)
OverlapHit overlap_capsule(Vec3, float, float, uint = 0xFFFFFFFF)
SweepHit sweep_capsule(Vec3, Vec3, float, float, uint = 0xFFFFFFFF)
uint get_trigger_event_count()
TriggerEvent get_trigger_event(uint)
Texture2D@ create_texture_2d(const string &in, uint, uint, const string &in)
Texture2D@ find_texture_2d(uint)
PostProcessPass@ add_post_process(const string &in, const string &in)
ShaderLayer@ find_layer(uint)
GameObject@ find_object(uint)
Group@ find_group(uint)
Vec3 get_world_position(Group@)
Vec3 get_world_position(GameObject@)
Vec3 transform_point(Group@, Vec3)
Vec3 inverse_transform_point(Group@, Vec3)
void set_hdr(bool)
bool get_hdr() const
void set_float(const string &in, float)
void set_int(const string &in, int)
void set_uint(const string &in, uint)
void set_vec3(const string &in, float, float, float)
float get_float(const string &in, float = 0)
int get_int(const string &in, int = 0)
uint get_uint(const string &in, uint = 0)
void clear_camera_path()
void add_camera_key(float, float, float, float, float, float, float = 60)
void clear_float_track(const string &in)
void add_float_key(const string &in, float, float)
float sample_float_track(const string &in, float, float = 0)
void set_video_resolution(int, int)
void set_video_fps(int)
void set_video_duration(float)
void set_video_output(const string &in)
void set_video_ffmpeg_args(const string &in)
void set_video_use_camera_path(bool)
bool save_state_json(const string &in)
bool load_state_json(const string &in)
string get_state_io_error() const
```

### `ShaderLayer`

Methods:

```cpp
void set_script(const string &in)
void set_enabled(bool)
bool set_blend_mode(const string &in)
bool set_primitive(const string &in)
void set_additive(bool)
void set_depth_test(bool)
void set_depth_write(bool)
void set_point_size(float)
void set_line_width(float)
void set_texture(const string &in, const string &in, bool = true)
void clear_texture(const string &in)
void bind_texture(const string &in, Texture2D@)
bool bind_image(const string &in, Texture2D@, const string &in = 'read_write')
void clear_shared_texture(const string &in)
void clear_image(const string &in)
void create_vec4_buffer(const string &in, uint, bool = false)
void set_buffer_vec4(const string &in, uint, float, float, float, float)
void create_uvec4_buffer(const string &in, uint, bool = false)
void set_buffer_uvec4(const string &in, uint, uint, uint, uint, uint)
uint get_buffer_size(const string &in)
void clear_buffer(const string &in)
bool load_vec4_buffer(const string &in, const string &in, bool = false)
bool save_vec4_buffer(const string &in, const string &in)
bool load_uvec4_buffer(const string &in, const string &in, bool = false)
bool save_uvec4_buffer(const string &in, const string &in)
string get_io_error() const
void set_compute_shader(const string &in, uint, uint = 1, uint = 1)
void clear_compute_shader()
void set_float(const string &in, float)
void set_int(const string &in, int)
void set_uint(const string &in, uint)
void set_vec2(const string &in, float, float)
void set_vec3(const string &in, float, float, float)
void set_vec4(const string &in, float, float, float, float)
float get_float(const string &in, float = 0)
int get_int(const string &in, int = 0)
uint get_uint(const string &in, uint = 0)
```

### `GameObject`

Methods:

```cpp
void set_script(const string &in)
void set_enabled(bool)
void set_group(Group@)
void set_position(float, float, float)
void set_rotation(float, float, float)
void set_scale(float, float, float)
void set_point_count(uint)
void set_batch_size(uint)
void set_lod(float, float, float)
void clear_lod()
void set_visibility_distance(float)
void set_float(const string &in, float)
void set_int(const string &in, int)
void set_uint(const string &in, uint)
void set_vec2(const string &in, float, float)
void set_vec3(const string &in, float, float, float)
void set_vec4(const string &in, float, float, float, float)
float get_float(const string &in, float = 0)
int get_int(const string &in, int = 0)
uint get_uint(const string &in, uint = 0)
uint get_id() const
Vec3 get_position() const
Vec3 get_rotation() const
Vec3 get_scale() const
bool get_enabled() const
uint get_group_id() const
```

### `Group`

Methods:

```cpp
void set_enabled(bool)
void set_parent(Group@)
void set_position(float, float, float)
void set_rotation(float, float, float)
void set_scale(float, float, float)
uint get_id() const
Vec3 get_position() const
Vec3 get_rotation() const
Vec3 get_scale() const
bool get_enabled() const
uint get_parent_id() const
```

### `Texture2D`

Methods:

```cpp
uint get_id() const
uint get_width() const
uint get_height() const
string get_format() const
```

### `PostProcessPass`

Methods:

```cpp
void set_enabled(bool)
void set_scale(float)
void set_input(const string &in, const string &in)
void clear_input(const string &in)
void set_float(const string &in, float)
void set_vec2(const string &in, float, float)
void set_vec3(const string &in, float, float, float)
void set_vec4(const string &in, float, float, float, float)
```

### `Collider`

Methods:

```cpp
void set_enabled(bool)
void set_trigger(bool)
void set_layer(uint)
void set_mask(uint)
void set_user_id(uint)
void set_position(Vec3)
void set_rotation(Vec3)
uint get_id() const
uint get_user_id() const
```

### `CharacterController`

Methods:

```cpp
void set_capsule(float, float)
void set_step_height(float)
void set_ground_snap_distance(float)
void set_slope_limit_degrees(float)
void set_collision_mask(uint)
MoveResult move(Vec3, float)
```

### `Json`

Methods:

```cpp
bool is_valid() const
bool is_object() const
bool is_array() const
uint size() const
bool has(const string &in) const
Json@ get(const string &in) const
Json@ at(uint) const
float as_float(float = 0) const
int as_int(int = 0) const
uint as_uint(uint = 0) const
bool as_bool(bool = false) const
string as_string(const string &in = '') const
void set_float(const string &in, float)
void set_int(const string &in, int)
void set_uint(const string &in, uint)
void set_bool(const string &in, bool)
void set_string(const string &in, const string &in)
void set_json(const string &in, Json@)
void push_json(Json@)
void push_float(float)
void push_string(const string &in)
bool save(const string &in, bool = true)
string dump(bool = true) const
string error() const
```

### `Vec2`

Constructors:

```cpp
Vec2()
Vec2(float, float)
```

Properties:

```cpp
float x
float y
```

Methods:

```cpp
Vec2 opAdd(const Vec2 &in) const
Vec2 opSub(const Vec2 &in) const
Vec2 opNeg() const
Vec2 opMul(float) const
Vec2 opDiv(float) const
```

### `Vec3`

Constructors:

```cpp
Vec3()
Vec3(float, float, float)
```

Properties:

```cpp
float x
float y
float z
```

Methods:

```cpp
Vec3 opAdd(const Vec3 &in) const
Vec3 opSub(const Vec3 &in) const
Vec3 opNeg() const
Vec3 opMul(float) const
Vec3 opDiv(float) const
```

### `Vec4`

Constructors:

```cpp
Vec4()
Vec4(float, float, float, float)
```

Properties:

```cpp
float x
float y
float z
float w
```

Methods:

```cpp
Vec4 opAdd(const Vec4 &in) const
Vec4 opSub(const Vec4 &in) const
Vec4 opNeg() const
Vec4 opMul(float) const
Vec4 opDiv(float) const
```

### `RayHit`

Properties:

```cpp
bool hit
uint collider_id
uint user_id
Vec3 point
Vec3 normal
float distance
```

### `SweepHit`

Properties:

```cpp
bool hit
uint collider_id
uint user_id
Vec3 point
Vec3 normal
float distance
float toi
bool started_overlapping
```

### `OverlapHit`

Properties:

```cpp
bool hit
uint collider_id
uint user_id
Vec3 normal
float depth
```

### `MoveResult`

Properties:

```cpp
Vec3 velocity
bool grounded
bool hit_wall
bool hit_ceiling
Vec3 ground_normal
```

### `TriggerEvent`

Properties:

```cpp
TriggerEventType type
uint trigger_collider_id
uint other_collider_id
uint trigger_user_id
uint other_user_id
```

### `TriggerEventType`

```cpp
Enter = 0
Stay  = 1
Exit  = 2
```
## Appendix B — Bundled AngelScript standard add-ons

The executable also registers the bundled AngelScript standard `string`, `array<T>`, and `dictionary` add-ons. These are not Stateless Pointcloud World concepts, but they are available to project scripts without extra libraries. The engine registers `array<T>` as the default array type. AngelScript language features such as functions, classes, interfaces, namespaces, enums, handles, control flow, casts and ordinary numeric types come from the language itself.

The following list is the user-callable method/global surface found in the bundled add-ons compiled with this project. Internal ref-count/GC behaviours are intentionally omitted because scripts do not call them directly.

```text
string :: string &opAssign(const string &in)
string :: string &opAddAssign(const string &in)
string :: bool opEquals(const string &in) const
string :: int opCmp(const string &in) const
string :: string opAdd(const string &in) const
string :: uint length() const
string :: void resize(uint)
string :: bool isEmpty() const
string :: uint8 &opIndex(uint)
string :: const uint8 &opIndex(uint) const
string :: string &opAssign(double)
string :: string &opAddAssign(double)
string :: string opAdd(double) const
string :: string opAdd_r(double) const
string :: string &opAssign(float)
string :: string &opAddAssign(float)
string :: string opAdd(float) const
string :: string opAdd_r(float) const
string :: string &opAssign(int64)
string :: string &opAddAssign(int64)
string :: string opAdd(int64) const
string :: string opAdd_r(int64) const
string :: string &opAssign(uint64)
string :: string &opAddAssign(uint64)
string :: string opAdd(uint64) const
string :: string opAdd_r(uint64) const
string :: string &opAssign(bool)
string :: string &opAddAssign(bool)
string :: string opAdd(bool) const
string :: string opAdd_r(bool) const
string :: string substr(uint start = 0, int count = -1) const
string :: int findFirst(const string &in, uint start = 0) const
string :: int findFirstOf(const string &in, uint start = 0) const
string :: int findFirstNotOf(const string &in, uint start = 0) const
string :: int findLast(const string &in, int start = -1) const
string :: int findLastOf(const string &in, int start = -1) const
string :: int findLastNotOf(const string &in, int start = -1) const
string :: void insert(uint pos, const string &in other)
string :: void erase(uint pos, int count = -1)
string :: int regexFind(const string  &in regex, uint start = 0, uint &out lengthOfMatch = void) const
global :: uint scan(const string&in str, ?&out ...)
global :: string format(const string&in fmt, const ?&in ...)
global :: string formatInt(int64 val, const string &in options = \"\", uint width = 0)
global :: string formatUInt(uint64 val, const string &in options = \"\", uint width = 0)
global :: string formatFloat(double val, const string &in options = \"\", uint width = 0, uint precision = 0)
global :: int64 parseInt(const string &in, uint base = 10, uint &out byteCount = 0)
global :: uint64 parseUInt(const string &in, uint base = 10, uint &out byteCount = 0)
global :: double parseFloat(const string &in, uint &out byteCount = 0)
array<T> :: T &opIndex(uint index)
array<T> :: const T &opIndex(uint index) const
array<T> :: uint opForBegin() const
array<T> :: bool opForEnd(uint) const
array<T> :: uint opForNext(uint) const
array<T> :: const T &opForValue0(uint index) const
array<T> :: uint opForValue1(uint index) const
array<T> :: array<T> &opAssign(const array<T>&in)
array<T> :: void insertAt(uint index, const T&in value)
array<T> :: void insertAt(uint index, const array<T>& arr)
array<T> :: void insertLast(const T&in value)
array<T> :: void removeAt(uint index)
array<T> :: void removeLast()
array<T> :: void removeRange(uint start, uint count)
array<T> :: uint length() const
array<T> :: void reserve(uint length)
array<T> :: void resize(uint length)
array<T> :: void sortAsc()
array<T> :: void sortAsc(uint startAt, uint count)
array<T> :: void sortDesc()
array<T> :: void sortDesc(uint startAt, uint count)
array<T> :: void reverse()
array<T> :: int find(const T&in if_handle_then_const value) const
array<T> :: int find(uint startAt, const T&in if_handle_then_const value) const
array<T> :: int findByRef(const T&in if_handle_then_const value) const
array<T> :: int findByRef(uint startAt, const T&in if_handle_then_const value) const
array<T> :: bool opEquals(const array<T>&in) const
array<T> :: bool isEmpty() const
array<T> :: void sort(const less &in, uint startAt = 0, uint count = uint(-1))
dictionaryValue :: dictionaryValue &opAssign(const dictionaryValue &in)
dictionaryValue :: dictionaryValue &opHndlAssign(const ?&in)
dictionaryValue :: dictionaryValue &opHndlAssign(const dictionaryValue &in)
dictionaryValue :: dictionaryValue &opAssign(const ?&in)
dictionaryValue :: dictionaryValue &opAssign(double)
dictionaryValue :: dictionaryValue &opAssign(int64)
dictionaryValue :: void opCast(?&out)
dictionaryValue :: void opConv(?&out)
dictionaryValue :: int64 opConv()
dictionaryValue :: double opConv()
dictionary :: dictionary &opAssign(const dictionary &in)
dictionary :: void set(const string &in, const ?&in)
dictionary :: bool get(const string &in, ?&out) const
dictionary :: void set(const string &in, const int64&in)
dictionary :: bool get(const string &in, int64&out) const
dictionary :: void set(const string &in, const double&in)
dictionary :: bool get(const string &in, double&out) const
dictionary :: bool exists(const string &in) const
dictionary :: bool isEmpty() const
dictionary :: uint getSize() const
dictionary :: bool delete(const string &in)
dictionary :: void deleteAll()
dictionary :: array<string> @getKeys() const
dictionary :: dictionaryValue &opIndex(const string &in)
dictionary :: const dictionaryValue &opIndex(const string &in) const
dictionary :: dictionaryIter @opForBegin() const
dictionary :: bool opForEnd(dictionaryIter @+) const
dictionary :: dictionaryIter @+ opForNext(dictionaryIter @+) const
dictionary :: const dictionaryValue &opForValue0(dictionaryIter @+) const
dictionary :: const string &opForValue1(dictionaryIter @+) const
```
